package clasificadores.genetica.seleccion;

import clasificadores.genetica.Poblacion;

public interface Seleccion {
	public Poblacion seleccionar(Poblacion P);
}

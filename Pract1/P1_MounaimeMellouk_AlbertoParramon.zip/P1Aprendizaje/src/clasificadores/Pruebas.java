package clasificadores;

import java.util.ArrayList;

import Datos.Datos;
import particionado.EstrategiaParticionado;
import particionado.Particion;
import particionado.ValidacionCruzada;

public class Pruebas {

	public static void main(String[] args) {
		
		Datos d = Datos.cargaDeFichero("tic-tac-toe.data");
		int numPart = 0;
		double prob = 0;
		ClasificadorNaiveBayes c = new ClasificadorNaiveBayes();
		EstrategiaParticionado part = new ValidacionCruzada();
		ArrayList<Particion> arrayPart = part.crearParticiones(d,numPart);
		Datos datosTrain = d.extraeDatosTrain(arrayPart.get(0));
		c.entrenamiento(datosTrain);
		
		// Calculamos la probabilidad P(Class=positive)
		
		prob = c.probClase("positive");
		System.out.println("Probabilidad a priori P(Class=positive) = " + prob);
		
		// Calculamos la probabilidad P(Class=negative)
		
		prob = c.probClase("negative");
		System.out.println("Probabilidad a priori P(Class=negative) = " + prob);
				
		// Calculamos la probabilidades de máxima verosimilitud con Laplace: 
		
		
		// P(MLeftSq=b|Class=positive) con Laplace
		
		prob =  c.probVlrAtrClaseLap("positive", "MLeftSq", "b");
		System.out.println("Probabilidad maxima verosimilitud P(MLeftSq=b|Class=positive) = " + prob);

		// P(TRightSq=x|Class=negative) con Laplace
		
		prob =  c.probVlrAtrClaseLap("negative", "TRightSq", "x");
		System.out.println("Probabilidad maxima verosimilitud P(TRightSq=x|Class=negative) = " + prob);

				
		
	}

}

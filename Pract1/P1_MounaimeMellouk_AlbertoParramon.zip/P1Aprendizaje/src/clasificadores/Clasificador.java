package clasificadores;
import java.util.ArrayList;
import java.util.Scanner;

import Datos.Datos;
import particionado.EstrategiaParticionado;
import particionado.Particion;
import particionado.ValidacionCruzada;
import particionado.ValidacionSimple;

abstract public class Clasificador {

	//Métodos abstractos que se implementan en cada clasificador concreto
	abstract public void entrenamiento (Datos datosTrain);
	abstract public ArrayList<String> clasifica (Datos datosTest, boolean laplace);
	
	// Obtiene el numero de aciertos y errores para calcular la tasa de fallo
	public double error (Datos datostest, ArrayList<String> Resclas) {
			
		    int numA = 0;
		    int numF = 0;
		    int numFila = 0;
		    
		    // pos,neg,pos,pos,neg   --> después de clasificar
			
			
			for(ArrayList<String> fila : datostest.getDatos()){
					String clase = datostest.obtClaseFila(fila);
					if(Resclas.get(numFila).equals(clase))	
						numA++;
					else numF++;
					numFila++;
			}
			return (double) numF/(numF+numA);
	}
	
	// Realiza una clasificacion utilizando una estrategia de particionado determinada
	public static ArrayList<Double> validacion(EstrategiaParticionado part, Datos datos,
			Clasificador clas, double porc, boolean laplace) {
		
		
		ArrayList<Double> erroresClas= new ArrayList<Double>();
		Datos datosTest;
		Datos datosTrain;
		ArrayList <String> resClas;
		ArrayList<Particion> arrayPart = part.crearParticiones(datos,porc);
		
		if(part.getNombreEstrategia()=="Validacion Simple"){
			
			datosTrain = datos.extraeDatosTrain(arrayPart.get(0));
			datosTest = datos.extraeDatosTest(arrayPart.get(0));
			clas.entrenamiento(datosTrain);
			resClas = clas.clasifica(datosTest,laplace);
		    erroresClas.add(clas.error(datosTest, resClas));
		    
		}else{
			
			for(Particion p : arrayPart){
				datosTrain = datos.extraeDatosTrain(p);
				datosTest = datos.extraeDatosTest(p);
				clas.entrenamiento(datosTrain);
				resClas = clas.clasifica(datosTest,laplace);
			    erroresClas.add(clas.error(datosTest, resClas));

		}
	}
		return erroresClas;
		
}
	


public static void main(String []args) {
		
	 
	 Datos d = Datos.cargaDeFichero("tic-tac-toe.data");
	 Clasificador c = new ClasificadorNaiveBayes();
	 EstrategiaParticionado part;
	 int porc;
	 boolean laplace;
	 ArrayList<Double> errores;
     
	 Scanner sc = new Scanner(System.in);
	 System.out.println("Introduzca S o N para indicar que se desea correccion de Laplace o no:");
	   String lap = sc.nextLine();
     System.out.println("Introduzca el tipo de validacion, S(simple) o C(cruzada)");
	 String val = sc.nextLine();
	 if(val.equals("S")){
		 part =  new ValidacionSimple ();
		 System.out.println("Introduzca el porcentaje de train (entre cero y cien)");
		  porc = sc.nextInt();
		  System.out.println("El porcentaje de error en la única partición es:");
	 }else{
		 part =  new ValidacionCruzada ();
		 System.out.println("Introduzca el numero k de particiones");
		 porc = sc.nextInt();
		 System.out.println("El porcentaje de errores por particion es el siguiente:");
	 }
	 laplace = (lap.equals("S")) ? true : false;
	 errores = Clasificador.validacion(part, d, c,porc,laplace);

	 sc.close();
	 
	 for(Double err : errores)
		 System.out.println(err);

	 }


}
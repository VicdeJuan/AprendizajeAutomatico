package clasificadores;

import java.util.ArrayList;

import Datos.Datos;
import Datos.Datos.TiposDeAtributos;

public class ClasificadorNaiveBayes extends Clasificador {
	
	ArrayList<ArrayList<Atr>> datosEntrenados; 
	ArrayList<String> clases;
	ArrayList<String> nombAtr;
	ArrayList<TiposDeAtributos> tipoAtrs;
	ArrayList<Double> probsClases;
	Datos datosTrain;
	ArrayList<AtrCont> atrCont;
	
	public ArrayList<ArrayList<Atr>> obtDatosEntrenados(){
		return this.datosEntrenados;
	}

	@Override
	public void entrenamiento(Datos datostrain) {
				
		datosTrain = datostrain;
		datosEntrenados = new  ArrayList<ArrayList<Atr>>();
		clases = datostrain.getClases();
		nombAtr = datostrain.getNombreAtrs();
		probsClases = datostrain.probClases();
		atrCont = new ArrayList<AtrCont>();
		
		for(String cls : datostrain.getClases()){
			ArrayList<Atr> at = new ArrayList<Atr>();
			for(String atr: datostrain.getA().keySet()){
				if(!datostrain.isContinuos(atr)){	
					Atr nuevoAt = new Atr(atr,datostrain.getA().get(atr));
					for(String valor:datostrain.getA().get(atr)){
						nuevoAt.getCoin().add(datostrain.obtNumCoinc(cls,atr,valor));		
					}
					at.add(nuevoAt);
				}else{
					double media = Datos.mediaDatos(datostrain, cls, atr);
					double var = Datos.VarDatos(datostrain, cls, atr, media);
					at.add(new AtrCont(atr,media,var));
				}
			}
			datosEntrenados.add(at);		

		}
		
	}

	@Override
	public ArrayList<String> clasifica(Datos datostest, boolean laplace) {

		double maxProb = 0;
		String clsMax = null;
		ArrayList<String> lista = new ArrayList<String>();
		ArrayList<String> atributos = new ArrayList<String>();
		
		for(ArrayList<String> fila: datostest.getDatos()){
			atributos = new ArrayList<String>();
			for(String atributo: fila){
				atributos.add(atributo);
			}
			atributos.remove(atributos.size()-1);
			maxProb=0;
			for(String clase: this.clases){
				
				double res = laplace ? probClaseAtrsLap(clase,atributos) : probClaseAtrs(clase,atributos);
				double probPost = res * this.probClase(clase);
				if(probPost>maxProb){
					clsMax = clase;
					maxProb = res;
				}
					
			}
			
			//if(clsMax==null)
				//clsMax = this.clases.get(0);
			lista.add(clsMax);		
			
		}
		
		
		return lista;
	}
	
	//calculamos P(ai|C) sin Laplace
	
	public double probVlrAtrClase(String clase, String nomAtr, String valor){
		
		int IndiceClase = this.clases.indexOf(clase);
		int numCoinGen= 0;
		int numCoinValor = 0;
		ArrayList<Atr> atributos = this.datosEntrenados.get(IndiceClase);
		for(Atr atributo: atributos){
			if(atributo.getNombre().equals(nomAtr)){
				
				if(datosTrain.isContinuos(nomAtr)){
					double media = ((AtrCont) atributo).getMedia();
					double var = ((AtrCont) atributo).getVar();
					return Datos.normalDistribution(Double.parseDouble(valor),media,var);
				} else{
					numCoinGen = Datos.sumArrayElems(atributo.getCoin());
					for(String val: atributo.getValores())
						if(val.equals(valor))
							numCoinValor = atributo.getCoin().get(atributo.getValores().indexOf(valor));
				}
				}
				
		}
		
		return  (double) numCoinValor/numCoinGen;
		
	}
	
	
//calculamos P(ai|C) con Laplace
	
	
public double probVlrAtrClaseLap(String clase, String nomAtr, String valor){
		
		int IndiceClase = this.clases.indexOf(clase);
		int numCoinGen= 0;
		int numCoinValor = 0;
		ArrayList<Atr> atributos = this.datosEntrenados.get(IndiceClase);
		for(Atr atributo: atributos){
			if(atributo.getNombre().equals(nomAtr)){
				
				if(datosTrain.isContinuos(nomAtr)){
					double media = ((AtrCont) atributo).getMedia();
					double var = ((AtrCont) atributo).getVar();
					return Datos.normalDistribution(Double.parseDouble(valor),media,var);
				} else{
					numCoinGen = Datos.sumArrayElems(atributo.getCoin());
					for(String val: atributo.getValores())
						if(val.equals(valor))
							numCoinValor = atributo.getCoin().get(atributo.getValores().indexOf(valor));
				}
			}
				
		}
		
		return  (double) (numCoinValor+1)/(numCoinGen+this.clases.size());
		
	}
	
	//calculamos P(a1,a2,....,an|C) sin Laplace
	
	public double probClaseAtrs(String clase, ArrayList<String> ValrAtrs){
		
		double res = 1;
		
		
		
		for(int i = 0; i< ValrAtrs.size();i++){
			res = res * probVlrAtrClase(clase, this.nombAtr.get(i), ValrAtrs.get(i));
			
		}
		
		return res;
		
		}
		
		
	//calculamos P(a1,a2,....,an|C) con Laplace
	
	public double probClaseAtrsLap(String clase, ArrayList<String> ValrAtrs){
		
		double res = 1;
		
		
		
		for(int i = 0; i< ValrAtrs.size();i++){
			res = res * probVlrAtrClaseLap(clase, this.nombAtr.get(i), ValrAtrs.get(i));
			
		}
		
		return res;
		
		}
	
	// P(C)
	
	public double probClase(String clase){
		
		return probsClases.get(this.clases.indexOf(clase));
	}
	
	
	public class Atr{
	 public	String nombre;
		public ArrayList<String> valores;
		public ArrayList<Integer> coinc;
		
		
		public Atr(String nombre,ArrayList<String> valores){
			this.nombre = nombre;
			this.valores = valores;
			this.coinc = new ArrayList<Integer>();
		}
		
		public String getNombre(){
			return this.nombre;
		}
		public void setNombre(String nombre){
			this.nombre = nombre;
			
		}
		
		public  ArrayList<String> getValores(){
			return this.valores;
		}
		public void setNombre( ArrayList<String> valores){
			this.valores = valores;
			
		}
		
		public  ArrayList<Integer> getCoin(){
			return this.coinc;
		}
		public void setCoinc( ArrayList<Integer> coinc){
			this.coinc = coinc;
			
		}
	}
	
	public class AtrCont extends Atr{
		
		String nombre;
		double media;
		double var;
		
		public AtrCont(String nombre,double media,	double var){
			super(nombre, new ArrayList<String>());
			this.nombre=nombre;
			this.media = media;
			this.var = var;
		}
		
		public String getNombre(){
			return this.nombre;
		}
		
		public double getMedia(){
			return this.media;
		}
		
		public double getVar(){
			return this.var;
		}
	}
	
}




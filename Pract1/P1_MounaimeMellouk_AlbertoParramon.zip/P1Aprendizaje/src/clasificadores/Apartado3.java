package clasificadores;

import java.util.ArrayList;
import java.util.Scanner;

import Datos.Datos;
import particionado.EstrategiaParticionado;
import particionado.Particion;
import particionado.ValidacionCruzada;

public class Apartado3 {

	public static void main(String[] args) {
		
		 int numPart;
		 double prob = 0;
		 Scanner sc = new Scanner(System.in);

		 Datos d = Datos.cargaDeFichero("tic-tac-toe.data");
		 System.out.println("Introduzca el numero de particiones:");
		 numPart = sc.nextInt();
		
		ClasificadorNaiveBayes c = new ClasificadorNaiveBayes();
		EstrategiaParticionado part = new ValidacionCruzada();
		ArrayList<Particion> arrayPart = part.crearParticiones(d,numPart);
		Datos datosTrain = d.extraeDatosTrain(arrayPart.get(0));
		c.entrenamiento(datosTrain);
		
		// Calculamos la probabilidad P(Class=positive)
		
		prob = c.probClase("positive");
		System.out.println("Probabilidad a priori P(Class=positive) = " + prob);
		
		// Calculamos la probabilidad P(Class=negative)
		
		prob = c.probClase("negative");
		System.out.println("Probabilidad a priori P(Class=negative) = " + prob);
				
		// Calculamos la probabilidades de máxima verosimilitud con Laplace: 
		
		
		// P(MLeftSq=b|Class=positive) sin Laplace
		
			System.out.println("Sin Laplace:");
			prob =  c.probVlrAtrClase("positive", "MLeftSq", "b");
			System.out.println("Probabilidad maxima verosimilitud P(MLeftSq=b|Class=positive) = " + prob);

			// P(TRightSq=x|Class=negative) con Laplace
				
			prob =  c.probVlrAtrClase("negative", "TRightSq", "x");
			System.out.println("Probabilidad maxima verosimilitud P(TRightSq=x|Class=negative) = " + prob);
		
		
		// P(MLeftSq=b|Class=positive) con Laplace
		
				System.out.println("Con Laplace:");

		prob =  c.probVlrAtrClaseLap("positive", "MLeftSq", "b");
		System.out.println("Probabilidad maxima verosimilitud P(MLeftSq=b|Class=positive) = " + prob);

		// P(TRightSq=x|Class=negative) con Laplace
		
		prob =  c.probVlrAtrClaseLap("negative", "TRightSq", "x");
		System.out.println("Probabilidad maxima verosimilitud P(TRightSq=x|Class=negative) = " + prob);

		sc.close();
		
	}

}

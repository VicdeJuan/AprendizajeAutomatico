package clasificadores;

import java.util.ArrayList;
import java.util.Scanner;

import Datos.Datos;
import particionado.EstrategiaParticionado;
import particionado.Particion;
import particionado.ValidacionCruzada;

public class Apartado4 {

	public static void main(String[] args) {
		
		 int numPart;
		 double prob = 0;
		 double media;
		double var;
			
		 Scanner sc = new Scanner(System.in);
		 
		
		Datos d = Datos.cargaDeFichero("crx.data");
		 
		System.out.println("Introduzca el numero de particiones:");
		numPart = sc.nextInt();
		 
		ClasificadorNaiveBayes c = new ClasificadorNaiveBayes();
		EstrategiaParticionado part = new ValidacionCruzada();
		//EstrategiaParticionado part = new ValidacionSimple();

		ArrayList<Particion> arrayPart = part.crearParticiones(d,numPart);
		Datos datosTrain = d.extraeDatosTrain(arrayPart.get(0));
		c.entrenamiento(datosTrain);
		
		// Calculamos la probabilidad P(Class=+)
		
		prob = c.probClase("+");
		System.out.println("Probabilidad a priori P(Class=+) = " + prob);
		
		// Calculamos la probabilidad P(Class=-)
		
		prob = c.probClase("-");
		System.out.println("Probabilidad a priori P(Class=-) = " + prob);
				
		// Calculamos la probabilidades de máxima verosimilitud con Laplace: 
		
		
		// P(A7=bb|Class=+) con Laplace
		
		prob =  c.probVlrAtrClaseLap("+", "A7", "bb");
		System.out.println("Probabilidad maxima verosimilitud P(A7=bb|Class=+) = " + prob);

		//P(A4=u|Class=-) con Laplace
		
		prob =  c.probVlrAtrClaseLap("-", "A4", "u");
		System.out.println("Probabilidad maxima verosimilitud P(A4=u|Class=-) = " + prob);

		// Media y desviación típica del  atributo continuo A2 condicionado al valor
		// de clase +
		
		media = Datos.mediaDatos(datosTrain, "+", "A2");
		var = Datos.VarDatos(datosTrain, "+", "A2", media);
		
		System.out.println("Media del atributo continuo A2 condicionado al valor de clase + = " + media);
		System.out.println("Desv. tipica del atributo continuo A2 condicionado al valor de clase + = " + Math.sqrt(var));

		
		// Media y desviación típica del  atributo continuo A14 condicionado al valor
		// de clase +
		
		media = Datos.mediaDatos(datosTrain, "+", "A14");
		var = Datos.VarDatos(datosTrain, "+", "A14", media);
		
		System.out.println("Media del atributo continuo A14 condicionado al valor de clase + = " + media);
		System.out.println("Desv. tipica del atributo continuo A14 condicionado al valor de clase + = " +Math.sqrt(var));

	
		
		// Media y desviación típica del  atributo continuo A15 condicionado al valor
		// de clase +
				
		media = Datos.mediaDatos(datosTrain, "+", "A15");
		var = Datos.VarDatos(datosTrain, "+", "A15", media);
		
		System.out.println("Media del atributo continuo A15 condicionado al valor de clase + = " + media);
		System.out.println("Desv. tipica del atributo continuo A15 condicionado al valor de clase + = " + Math.sqrt(var));

		
		sc.close();
		
	}

}
